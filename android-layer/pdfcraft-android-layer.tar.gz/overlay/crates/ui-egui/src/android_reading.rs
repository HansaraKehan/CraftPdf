//! Android reading mode. Added by the Android layer (apply_layer.py hooks it in with one-line edits).
//!
//! With `hide_bars_in_read` on, Read mode shows the page alone: the tab strip, the mode bar, the rail and
//! the panes are hidden. A tap on the page (sent by the Android host) brings them back; the next tap puts
//! them away again. Read mode also fits the page to the screen width, edge to edge.

#![allow(deprecated)] // egui::Id::new

use crate::canvas::{DocView, Fit};
use crate::{Mode, PdfCraftApp};

impl PdfCraftApp {
    /// Read mode with nothing beside the page: it then fills the screen width.
    pub fn read_edge_to_edge(&self) -> bool {
        self.hide_bars_in_read && self.mode == Mode::Read && self.right.is_none() && !self.full_screen
    }

    /// Whether Read mode is showing the page alone right now.
    pub fn read_bars_hidden(&self) -> bool {
        self.hide_bars_in_read && self.mode == Mode::Read && !self.read_bars_shown && self.active.is_some() && !self.full_screen
    }

    /// A tap on the page while reading: bring the bars back, or put them away again.
    pub fn toggle_read_bars(&mut self) {
        if self.hide_bars_in_read && self.mode == Mode::Read && self.active.is_some() {
            self.read_bars_shown = !self.read_bars_shown;
        }
    }

    /// Called as `mode` is about to become the current mode. Entering or leaving Read starts with the
    /// bars hidden; entering it fits the page to the screen width (the reader can change that after).
    pub(crate) fn android_enter_mode(&mut self, mode: Mode) {
        let entering_read = self.hide_bars_in_read && mode == Mode::Read && self.mode != Mode::Read;
        self.read_bars_shown = false;
        if entering_read && let Some(view) = self.active.and_then(|i| self.views.get_mut(i)) {
            view.set_fit(Fit::Width);
        }
    }

    /// Called after a document was opened: one opened while already reading fits the width too.
    pub(crate) fn android_after_open(&mut self, activate: bool) {
        if activate && self.hide_bars_in_read && self.mode == Mode::Read && let Some(view) = self.views.last_mut() {
            view.set_fit(Fit::Width);
        }
    }
}

/// What the zoom button's list can pick.
enum ZoomChoice {
    Percent(f32),
    FitWidth,
}

/// A zoom button next to the side bar, drawn by the layer itself (so it does not depend on how upstream lays
/// out its zoom box, which cannot be typed in without a keyboard): it shows the zoom now, and tapping it
/// lists 50% to 300% and "Fit to display".
fn zoom_button(ctx: &egui::Context, view: &mut DocView) {
    let mut choice = None;
    egui::Area::new(egui::Id::new("android-zoom-button"))
        .order(egui::Order::Foreground)
        .anchor(egui::Align2::LEFT_BOTTOM, egui::vec2(16.0, -16.0))
        .show(ctx, |ui| {
            let label = egui::RichText::new(format!("{:.0}%", view.zoom * 100.0)).size(16.0);
            let button = ui.add(egui::Button::new(label).min_size(egui::vec2(72.0, 44.0)));
            choice = egui::Popup::menu(&button)
                .show(|ui| {
                    let mut choice = None;
                    for percent in [50, 75, 100, 125, 150, 200, 300] {
                        if ui.button(format!("{percent}%")).clicked() {
                            choice = Some(ZoomChoice::Percent(percent as f32 / 100.0));
                            ui.close();
                        }
                    }
                    ui.separator();
                    if ui.button("Fit to display").clicked() {
                        choice = Some(ZoomChoice::FitWidth);
                        ui.close();
                    }
                    choice
                })
                .and_then(|r| r.inner);
        });
    match choice {
        Some(ZoomChoice::Percent(zoom)) => view.set_zoom(zoom),
        Some(ZoomChoice::FitWidth) => view.set_fit(Fit::Width),
        None => {}
    }
}

impl PdfCraftApp {
    /// Called once a frame, before the panels: tells the page view whether Read mode fills the screen
    /// width, and shows the zoom button while the bars are shown in Read mode.
    pub(crate) fn android_frame(&mut self, ctx: &egui::Context) {
        crate::canvas::set_edge_to_edge(self.read_edge_to_edge());
        // What the current tool does with a finger, for the page view (see canvas/android_touch.rs).
        let mode = crate::canvas::touch_mode(self);
        ctx.data_mut(|d| d.insert_temp(egui::Id::new("android.touch_mode"), mode));
        if self.hide_bars_in_read
            && self.mode == Mode::Read
            && self.read_bars_shown
            && !self.full_screen
            && let Some(view) = self.active.and_then(|i| self.views.get_mut(i))
        {
            zoom_button(ctx, view);
        }
    }
}
