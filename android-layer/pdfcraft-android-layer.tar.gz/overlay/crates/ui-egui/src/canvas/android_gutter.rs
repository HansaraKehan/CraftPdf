//! Android: the gutter beside the page. Added by the Android layer.
//!
//! Upstream keeps pages `SIDE` points clear of the left and right edges (room for the floating quick
//! bar). Read mode hides that bar, so it asks for no gutter and the page fills the screen width.

use std::sync::atomic::{AtomicBool, Ordering};

static EDGE_TO_EDGE: AtomicBool = AtomicBool::new(false);

pub(crate) fn set_edge_to_edge(on: bool) {
    EDGE_TO_EDGE.store(on, Ordering::Relaxed);
}

pub(crate) fn side_gutter() -> f32 {
    if EDGE_TO_EDGE.load(Ordering::Relaxed) { 0.0 } else { super::SIDE }
}
