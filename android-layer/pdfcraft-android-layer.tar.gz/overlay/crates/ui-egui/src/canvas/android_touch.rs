//! Android: touch support in the page view. Added by the Android layer.
//!
//! The Android host turns a swipe on the page into scrolling and a held finger into a text selection.
//! It needs to know where the page view is, and the page view needs to know where a finger tapped.

#![allow(deprecated)] // egui::Id::new

use super::DocView;

/// Tell the host where the page area is, and whether holding a finger there selects text (the Hand tool
/// only scrolls). Called just before the page widget is allocated.
pub(super) fn publish_page(ctx: &egui::Context, page_area: egui::Rect, hand: bool, selects_text: bool) {
    ctx.data_mut(|d| {
        let key = egui::Id::new("android.page_rect");
        d.insert_temp(key, if hand || selects_text { Some((page_area, selects_text)) } else { None::<(egui::Rect, bool)> });
    });
}

/// Called right after the page widget: a tap on the page closes a context menu left open, and a finger
/// tap on the page (not on a menu above it) clears the text selection.
pub(super) fn after_page(ui: &mut egui::Ui, resp: &egui::Response, resp_rect: egui::Rect, view: &mut DocView) {
    if resp.clicked() {
        egui::Popup::close_all(ui.ctx());
    }
    if let Some(pos) = ui.ctx().data(|d| d.get_temp::<Option<egui::Pos2>>(egui::Id::new("android.tap_pos"))).flatten()
        && resp_rect.contains(pos)
        && ui.ctx().layer_id_at(pos) == Some(ui.layer_id())
    {
        view.selection = None;
    }
}
