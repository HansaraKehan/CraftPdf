//! Looks for a newer build of this app in the GitHub repository it was built from, a few seconds after start,
//! and offers it: Download, Remind me later, or Skip this version. Only public release information is read.

use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use android_activity::AndroidApp;
use jni::objects::{JString, JValue};

/// The repository this build came from (set by the workflow), whose Releases hold newer builds.
const REPO: &str = match option_env!("GITHUB_REPOSITORY") {
    Some(repo) => repo,
    None => "HansaraKehan/CraftPdf",
};

struct Offer {
    tag: String,
    installed: String,
    page: String,
    apk: String,
}

/// What the user told the check: a version to leave alone, and a time before which not to ask again.
#[derive(Default)]
struct Choice {
    skipped: String,
    remind_after: u64,
}

pub struct Updates {
    app: AndroidApp,
    launched: Instant,
    started: bool,
    choice: Choice,
    file: Option<PathBuf>,
    offer: Option<Offer>,
}

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

/// A button big enough for a finger.
fn touch_button(text: &str) -> egui::Button<'_> {
    egui::Button::new(text).min_size(egui::vec2(120.0, 44.0))
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    crate::with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

impl Updates {
    /// `private` is the app's private folder, where the choice is remembered (`update.json`).
    pub fn new(app: AndroidApp, private: Option<&Path>) -> Self {
        let file = private.map(|dir| dir.join("config").join("update.json"));
        let value: serde_json::Value = file.as_ref().and_then(|f| std::fs::read(f).ok()).and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
        let choice = Choice {
            skipped: value.get("skipped").and_then(|v| v.as_str()).unwrap_or_default().to_string(),
            remind_after: value.get("remind_after").and_then(|v| v.as_u64()).unwrap_or(0),
        };
        Self { app, launched: Instant::now(), started: false, choice, file, offer: None }
    }

    fn remember(&self) {
        let Some(path) = &self.file else { return };
        let value = serde_json::json!({ "skipped": self.choice.skipped, "remind_after": self.choice.remind_after });
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        let _ = std::fs::write(path, value.to_string());
    }

    /// Call every frame: sends the check a few seconds after start, and reads its answer.
    pub fn tick(&mut self) {
        if !self.started && self.launched.elapsed() > Duration::from_secs(5) {
            self.started = true;
            if now_secs() >= self.choice.remind_after {
                crate::with_activity(&self.app, |env, activity| {
                    let repo = env.new_string(REPO)?;
                    env.call_method(activity, "startUpdateCheck", "(Ljava/lang/String;)V", &[JValue::from(&repo)])?;
                    Ok(())
                });
            }
        }
        if !self.started || self.offer.is_some() {
            return;
        }
        if let Some(reply) = read_string(&self.app, "pollUpdate")
            && let Some(rest) = reply.strip_prefix("OK\n")
        {
            let mut lines = rest.split('\n');
            let (tag, page, apk) = (lines.next().unwrap_or(""), lines.next().unwrap_or(""), lines.next().unwrap_or(""));
            let installed = read_string(&self.app, "installedVersion").unwrap_or_default();
            if !tag.is_empty() && tag != installed && tag != self.choice.skipped {
                self.offer = Some(Offer { tag: tag.to_string(), installed, page: page.to_string(), apk: apk.to_string() });
            }
        }
    }

    /// Call every frame, after the app's own interface: draws the offer when there is one.
    pub fn show(&mut self, ctx: &egui::Context) {
        let Some(offer) = &self.offer else { return };
        enum Pick {
            Download,
            Later,
            Skip,
        }
        let mut pick = None;
        egui::Window::new("A new version is available")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .show(ctx, |ui| {
                ui.label("A newer build of PdfCraft for Android is ready to download.");
                ui.add_space(4.0);
                ui.label(format!("Installed: {}", if offer.installed.is_empty() { "unknown" } else { &offer.installed }));
                ui.label(format!("New: {}", offer.tag));
                ui.add_space(8.0);
                ui.horizontal_wrapped(|ui| {
                    if ui.add(touch_button("Download")).clicked() {
                        pick = Some(Pick::Download);
                    }
                    if ui.add(touch_button("Remind me later")).clicked() {
                        pick = Some(Pick::Later);
                    }
                    if ui.add(touch_button("Skip this version")).clicked() {
                        pick = Some(Pick::Skip);
                    }
                });
            });
        let Some(pick) = pick else { return };
        let Some(offer) = self.offer.take() else { return };
        match pick {
            Pick::Download => {
                // The APK itself when the release has one, else the release page; ask again tomorrow if it was not installed.
                crate::open_link(&self.app, if offer.apk.is_empty() { &offer.page } else { &offer.apk });
                self.choice.remind_after = now_secs() + 24 * 3600;
            }
            Pick::Later => self.choice.remind_after = now_secs() + 24 * 3600,
            Pick::Skip => self.choice.skipped = offer.tag,
        }
        self.remember();
    }
}
