//! PdfCraft for Android: runs the shared egui UI (`pdfcraft-ui-egui`) inside a NativeActivity.
//!
//! - File dialogs are answered by Android's own picker (no storage permission): `vendor/rfd-android`
//!   routes PdfCraft's `rfd::AsyncFileDialog` calls here, the Java activity copies the chosen document
//!   to a private folder, and later saves are written back to the original location.
//! - Web links open in the browser through the Java activity; PDFs other apps open with PdfCraft arrive
//!   the same way. Settings and recovery copies live in the app's private folder.
//! - Not yet: system clipboard (`vendor/arboard-android`), printing, update checks.
#![cfg(target_os = "android")]

use std::path::PathBuf;
use std::sync::{Mutex, mpsc};
use std::time::Duration;

use android_activity::AndroidApp;
use eframe::App as _;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use pdfcraft_ui_egui::PdfCraftApp;

/// The answer channel of the dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<Vec<PathBuf>>>> = Mutex::new(None);

struct App {
    app: PdfCraftApp,
    android: AndroidApp,
}

impl eframe::App for App {
    fn raw_input_hook(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.app.raw_input_hook(ctx, raw);
    }
    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        self.app.save(storage);
    }
    fn logic(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android) {
            self.app.open_path(&path);
        }
        if let Some(paths) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(paths);
        }
        self.app.logic(ctx, frame);
        // Wake now and then to see a document another app handed us, or a picker answer.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn ui(&mut self, ui: &mut egui::Ui, frame: &mut eframe::Frame) {
        self.app.ui(ui, frame);
        open_links(ui.ctx(), &self.android);
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// The next document another app opened with us (a file path), if any.
fn poll_open(app: &AndroidApp) -> Option<String> {
    read_string(app, "pollOpen").filter(|path| !path.is_empty())
}

/// The picker's answer once it has closed: the chosen paths (none = cancelled).
fn poll_pick(app: &AndroidApp) -> Option<Vec<PathBuf>> {
    let answer = read_string(app, "pollPick").filter(|a| !a.is_empty())?;
    Some(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(PathBuf::from).collect()).unwrap_or_default())
}

/// Show Android's file picker. kind: 0 open one, 1 open several, 2 save, 3 folder.
fn show_picker(app: &AndroidApp, kind: i32, name: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        env.call_method(activity, "startPick", "(ILjava/lang/String;)V", &[JValue::Int(kind), JValue::from(&name)])?;
        Ok(())
    })
    .is_some()
}

/// The `rfd` backend: show the dialog, and give back a receiver for the chosen paths.
fn start_pick(app: &AndroidApp, request: rfd::Request) -> Option<mpsc::Receiver<Vec<PathBuf>>> {
    let kind = match request.kind {
        rfd::Kind::File => 0,
        rfd::Kind::Files => 1,
        rfd::Kind::Save => 2,
        rfd::Kind::Folder => 3,
    };
    if !show_picker(app, kind, &request.file_name) {
        return None;
    }
    let (tx, rx) = mpsc::channel();
    *EXTERNAL.lock().ok()? = Some(tx);
    Some(rx)
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// PdfCraft opens links through egui; do that here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("PdfCraft").with_max_level(log::LevelFilter::Info));
    // Settings, recovery copies and caches go in the app's private folder.
    if let Some(dir) = app.internal_data_path() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe {
            std::env::set_var("HOME", &dir);
            std::env::set_var("XDG_CONFIG_HOME", dir.join("config"));
            std::env::set_var("XDG_DATA_HOME", dir.join("data"));
            std::env::set_var("XDG_CACHE_HOME", dir.join("cache"));
        }
    }
    let android = app.clone();
    let picker = app.clone();
    rfd::set_backend(move |request| start_pick(&picker, request));
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "PdfCraft",
        options,
        Box::new(move |cc| {
            let mut app = PdfCraftApp::new();
            app.units = pdfcraft_ui_egui::units::Unit::system();
            if let Some(json) = cc.storage.and_then(|s| s.get_string("pdfcraft")) {
                app.restore(&json);
            }
            // Android owns the window: no title bar of our own to draw buttons into.
            app.integrated_titlebar = false;
            // Autosave unsaved changes; offer to recover documents a crashed session left behind.
            if let Some(dir) = pdfcraft_ui_egui::RecoveryStore::default_dir() {
                app.enable_recovery(pdfcraft_ui_egui::RecoveryStore::new(dir));
            }
            Ok(Box::new(App { app, android }))
        }),
    );
    if let Err(error) = result {
        log::error!("PdfCraft failed to start: {error}");
    }
}
