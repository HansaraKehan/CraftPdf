//! PdfCraft for Android: runs the shared egui UI (`pdfcraft-ui-egui`) inside a NativeActivity.
//!
//! - File dialogs are answered by Android's own picker (no storage permission): `vendor/rfd-android`
//!   routes PdfCraft's `rfd::AsyncFileDialog` calls here, the Java activity copies the chosen document
//!   to a private folder, and later saves are written back to the original location.
//! - Web links open in the browser through the Java activity; PDFs other apps open with PdfCraft arrive
//!   the same way. Settings and recovery copies live in the app's private folder.
//! - Not yet: system clipboard (`vendor/arboard-android`), printing, update checks.
#![cfg(target_os = "android")]

use std::path::PathBuf;
use std::sync::{Mutex, mpsc};
use std::time::Duration;

use android_activity::AndroidApp;
use eframe::App as _;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use pdfcraft_ui_egui::PdfCraftApp;

/// The answer channel of the dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<Vec<PathBuf>>>> = Mutex::new(None);

/// How long a finger must stay still before it selects instead of scrolling.
const HOLD: f64 = 0.45;
/// How far (points) a finger may wander and still count as held.
const SLOP: f32 = 10.0;

#[derive(PartialEq)]
enum Mode {
    /// Down, not yet moved or held: could still be a tap, a scroll or a selection.
    Pending,
    /// Moving: the page scrolls with the finger.
    Scroll,
    /// Held still, then dragged: a real press, so the page selects text.
    Select,
}

/// One finger on the page, followed from touch-down.
struct Gesture {
    id: egui::TouchId,
    start: egui::Pos2,
    last: egui::Pos2,
    started_at: f64,
    mode: Mode,
}

#[derive(Default)]
struct Touch {
    /// Fingers on the screen.
    fingers: u32,
    gesture: Option<Gesture>,
    /// The pointer events egui-winit makes from a finger that is scrolling are dropped, up to its `PointerGone`.
    drop_pointer: bool,
    /// Where a held finger lifted: the context menu (Copy, Highlight…) opens there.
    menu_at: Option<egui::Pos2>,
}

fn wheel(delta: egui::Vec2, phase: egui::TouchPhase, modifiers: egui::Modifiers) -> egui::Event {
    egui::Event::MouseWheel { unit: egui::MouseWheelUnit::Point, delta, phase, modifiers }
}

fn click(pos: egui::Pos2, button: egui::PointerButton, modifiers: egui::Modifiers) -> [egui::Event; 3] {
    [
        egui::Event::PointerMoved(pos),
        egui::Event::PointerButton { pos, button, pressed: true, modifiers },
        egui::Event::PointerButton { pos, button, pressed: false, modifiers },
    ]
}

struct App {
    app: PdfCraftApp,
    android: AndroidApp,
    touch: Touch,
}

impl App {
    /// On the page: a finger that moves scrolls it (as a trackpad swipe would), a tap clicks, and a finger
    /// held still starts a text selection that the drag that follows extends. Everywhere else, and for a
    /// mouse or pen, input is left alone. The page view says where it is (`android.page_rect`, set only while
    /// a text-selecting tool is active).
    fn filter_touch(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        let now = raw.time.unwrap_or(0.0);
        let page = ctx.data(|d| d.get_temp::<egui::Rect>(egui::Id::new("android.page_rect")));
        let modifiers = raw.modifiers;
        let t = &mut self.touch;
        let mut out = Vec::with_capacity(raw.events.len() + 4);
        for event in std::mem::take(&mut raw.events) {
            if let egui::Event::Touch { id, phase, pos, .. } = &event {
                match phase {
                    egui::TouchPhase::Start => {
                        t.fingers += 1;
                        // A second finger is a pinch: never a scroll or a selection.
                        t.gesture = (t.fingers == 1 && page.is_some_and(|r| r.contains(*pos)))
                            .then(|| Gesture { id: *id, start: *pos, last: *pos, started_at: now, mode: Mode::Pending });
                        t.drop_pointer = t.gesture.is_some() || t.drop_pointer && t.fingers > 1;
                    }
                    egui::TouchPhase::Move => {
                        if let Some(g) = t.gesture.as_mut()
                            && g.id == *id
                        {
                            match g.mode {
                                Mode::Pending if pos.distance(g.start) > SLOP => {
                                    g.mode = Mode::Scroll;
                                    out.push(wheel(*pos - g.start, egui::TouchPhase::Start, modifiers));
                                    g.last = *pos;
                                }
                                Mode::Scroll => {
                                    out.push(wheel(*pos - g.last, egui::TouchPhase::Move, modifiers));
                                    g.last = *pos;
                                }
                                _ => {}
                            }
                        }
                    }
                    egui::TouchPhase::End | egui::TouchPhase::Cancel => {
                        t.fingers = t.fingers.saturating_sub(1);
                        if let Some(g) = t.gesture.take_if(|g| g.id == *id) {
                            let ended = *phase == egui::TouchPhase::End;
                            match g.mode {
                                Mode::Pending if ended => {
                                    out.extend(click(*pos, egui::PointerButton::Primary, modifiers));
                                    out.push(egui::Event::PointerGone);
                                }
                                Mode::Scroll => out.push(wheel(egui::Vec2::ZERO, egui::TouchPhase::End, modifiers)),
                                Mode::Select if ended => t.menu_at = Some(*pos),
                                _ => {}
                            }
                        }
                    }
                }
                // Touch events always go on: egui measures pinch zoom from them.
                out.push(event);
                continue;
            }
            if matches!(event, egui::Event::PointerGone) {
                // The finger is up. A held-then-selected text opens its menu (Copy, Highlight…) where it lifted.
                if let Some(pos) = t.menu_at.take() {
                    t.drop_pointer = false;
                    out.push(event);
                    out.extend(click(pos, egui::PointerButton::Secondary, modifiers));
                    continue;
                }
                if t.drop_pointer && t.gesture.is_none() {
                    t.drop_pointer = false;
                    continue;
                }
            }
            let pointer_event = matches!(event, egui::Event::PointerMoved(_) | egui::Event::PointerButton { .. } | egui::Event::PointerGone);
            if pointer_event && t.drop_pointer && t.gesture.as_ref().is_none_or(|g| g.mode != Mode::Select) {
                continue;
            }
            out.push(event);
        }
        // Held still long enough: press where the finger went down, and let the drag extend the selection.
        if let Some(g) = t.gesture.as_mut()
            && g.mode == Mode::Pending
            && now - g.started_at >= HOLD
        {
            g.mode = Mode::Select;
            t.drop_pointer = false;
            out.push(egui::Event::PointerMoved(g.start));
            out.push(egui::Event::PointerButton { pos: g.start, button: egui::PointerButton::Primary, pressed: true, modifiers });
        }
        if t.gesture.as_ref().is_some_and(|g| g.mode == Mode::Pending) {
            // No event arrives while the finger rests: wake up to notice the hold.
            ctx.request_repaint_after(Duration::from_millis(100));
        }
        raw.events = out;
    }
}

impl eframe::App for App {
    fn raw_input_hook(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.filter_touch(ctx, raw);
        self.app.raw_input_hook(ctx, raw);
    }
    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        self.app.save(storage);
    }
    fn logic(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android) {
            self.app.open_path(&path);
        }
        if let Some(paths) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(paths);
        }
        self.app.logic(ctx, frame);
        // Wake now and then to see a document another app handed us, or a picker answer.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn ui(&mut self, ui: &mut egui::Ui, frame: &mut eframe::Frame) {
        self.app.ui(ui, frame);
        open_links(ui.ctx(), &self.android);
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// The next document another app opened with us (a file path), if any.
fn poll_open(app: &AndroidApp) -> Option<String> {
    read_string(app, "pollOpen").filter(|path| !path.is_empty())
}

/// The picker's answer once it has closed: the chosen paths (none = cancelled).
fn poll_pick(app: &AndroidApp) -> Option<Vec<PathBuf>> {
    let answer = read_string(app, "pollPick").filter(|a| !a.is_empty())?;
    Some(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(PathBuf::from).collect()).unwrap_or_default())
}

/// Show Android's file picker. kind: 0 open one, 1 open several, 2 save, 3 folder.
fn show_picker(app: &AndroidApp, kind: i32, name: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        env.call_method(activity, "startPick", "(ILjava/lang/String;)V", &[JValue::Int(kind), JValue::from(&name)])?;
        Ok(())
    })
    .is_some()
}

/// The `rfd` backend: show the dialog, and give back a receiver for the chosen paths.
fn start_pick(app: &AndroidApp, request: rfd::Request) -> Option<mpsc::Receiver<Vec<PathBuf>>> {
    let kind = match request.kind {
        rfd::Kind::File => 0,
        rfd::Kind::Files => 1,
        rfd::Kind::Save => 2,
        rfd::Kind::Folder => 3,
    };
    if !show_picker(app, kind, &request.file_name) {
        return None;
    }
    let (tx, rx) = mpsc::channel();
    *EXTERNAL.lock().ok()? = Some(tx);
    Some(rx)
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// PdfCraft opens links through egui; do that here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("PdfCraft").with_max_level(log::LevelFilter::Info));
    // Settings, recovery copies and caches go in the app's private folder.
    if let Some(dir) = app.internal_data_path() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe {
            std::env::set_var("HOME", &dir);
            std::env::set_var("XDG_CONFIG_HOME", dir.join("config"));
            std::env::set_var("XDG_DATA_HOME", dir.join("data"));
            std::env::set_var("XDG_CACHE_HOME", dir.join("cache"));
        }
    }
    let android = app.clone();
    let picker = app.clone();
    rfd::set_backend(move |request| start_pick(&picker, request));
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "PdfCraft",
        options,
        Box::new(move |cc| {
            let mut app = PdfCraftApp::new();
            app.units = pdfcraft_ui_egui::units::Unit::system();
            let saved = cc.storage.and_then(|s| s.get_string("pdfcraft"));
            match &saved {
                Some(json) => app.restore(json),
                // First launch: bring the PDFs that were open back next time (the user can turn it off).
                None => app.reopen_last_session = true,
            }
            // Android owns the window: no title bar of our own to draw buttons into.
            app.integrated_titlebar = false;
            // Autosave unsaved changes; offer to recover documents a crashed session left behind.
            if let Some(dir) = pdfcraft_ui_egui::RecoveryStore::default_dir() {
                app.enable_recovery(pdfcraft_ui_egui::RecoveryStore::new(dir));
            }
            // The files that were open when the app last closed. Their private copies are still there.
            app.reopen_last_files(&[]);
            Ok(Box::new(App { app, android, touch: Touch::default() }))
        }),
    );
    if let Err(error) = result {
        log::error!("PdfCraft failed to start: {error}");
    }
}
