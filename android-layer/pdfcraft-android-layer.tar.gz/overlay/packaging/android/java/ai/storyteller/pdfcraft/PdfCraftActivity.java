package ai.storyteller.pdfcraft;

import android.app.NativeActivity;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.URL;
import java.net.HttpURLConnection;
import android.content.pm.PackageInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.content.ClipData;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * NativeActivity that runs full screen, opens web links, and handles documents without any storage
 * permission: File > Open / Save As use Android's own picker (Storage Access Framework); the chosen
 * document is copied to a private folder, PdfCraft works on that copy, and every later save is
 * written back to the original location. Other apps can open documents with PdfCraft the same way.
 */
public class PdfCraftActivity extends NativeActivity {
    private static final int REQ_PICK = 4711;

    private static class Tracked {
        Uri uri;
        long synced;
        long failedFor;
        Tracked(Uri uri, long synced) {
            this.uri = uri;
            this.synced = synced;
        }
    }

    private final ConcurrentLinkedQueue<String> opened = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> updates = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> picked = new ConcurrentLinkedQueue<>();
    private final Map<String, Tracked> tracked = new HashMap<>();
    private int pickKind;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        getWindow().setAttributes(params);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        loadTracked();
        startSyncThread();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** Called from Rust: the next document another app opened with us (a file path), or "". */
    public String pollOpen() {
        String path = opened.poll();
        return path == null ? "" : path;
    }

    /** Called from Rust: the picker's answer ("CANCEL", or "OK" and one path per line), or "". */
    public String pollPick() {
        String answer = picked.poll();
        return answer == null ? "" : answer;
    }

    /** Called from Rust: show Android's file picker. kind: 0 open one, 1 open several, 2 save, 3 folder. */
    public void startPick(final int kind, final String name) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    pickKind = kind;
                    Intent intent;
                    if (kind == 2) {
                        intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType(mimeFor(name));
                        intent.putExtra(Intent.EXTRA_TITLE, name);
                    } else if (kind == 3) {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    } else {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, kind == 1);
                    }
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, REQ_PICK);
                } catch (Exception e) {
                    picked.add("CANCEL");
                }
            }
        });
    }

    @Override protected void onActivityResult(int request, int result, final Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ_PICK) return;
        if (result != RESULT_OK || data == null) {
            picked.add("CANCEL");
            return;
        }
        final int kind = pickKind;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    StringBuilder answer = new StringBuilder("OK");
                    if (kind == 3) {
                        // A folder is used in place, which only works where we may read shared storage.
                        String path = data.getData() == null ? null
                            : pathFromDocId(DocumentsContract.getTreeDocumentId(data.getData()));
                        if (path == null || !new File(path).canRead()) {
                            picked.add("CANCEL");
                            return;
                        }
                        answer.append('\n').append(path);
                    } else {
                        ArrayList<Uri> uris = new ArrayList<>();
                        ClipData clip = data.getClipData();
                        if (clip != null) {
                            for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
                        } else if (data.getData() != null) {
                            uris.add(data.getData());
                        }
                        for (Uri uri : uris) {
                            keepAccess(uri);
                            String path = kind == 2 ? prepareSave(uri) : importDocument(uri);
                            if (path != null) answer.append('\n').append(path);
                        }
                    }
                    picked.add(answer.toString());
                } catch (Exception e) {
                    picked.add("CANCEL");
                }
            }
        }).start();
    }

    /** "primary:Documents/Art" -> /storage/emulated/0/Documents/Art (other volumes: /storage/<id>/...). */
    private static String pathFromDocId(String id) {
        if (id == null) return null;
        int colon = id.indexOf(':');
        if (colon < 0) return null;
        String volume = id.substring(0, colon);
        String rest = id.substring(colon + 1);
        String base = "primary".equals(volume) ? "/storage/emulated/0" : "/storage/" + volume;
        return rest.isEmpty() ? base : base + "/" + rest;
    }

    /** Called from Rust: the version of the installed app (the release it was built as). */
    public String installedVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Called from Rust: look up the newest release of a GitHub repository. */
    public void startUpdateCheck(final String repo) {
        new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/releases/latest").openConnection();
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    connection.setRequestProperty("User-Agent", "PdfCraft-Android");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    if (connection.getResponseCode() != 200) {
                        updates.add("NONE");
                        return;
                    }
                    InputStream in = connection.getInputStream();
                    java.io.ByteArrayOutputStream body = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) > 0 && body.size() < 512 * 1024) body.write(buffer, 0, n);
                    in.close();
                    JSONObject release = new JSONObject(body.toString("UTF-8"));
                    String apk = "";
                    JSONArray assets = release.optJSONArray("assets");
                    if (assets != null) {
                        for (int i = 0; i < assets.length() && apk.isEmpty(); i++) {
                            String url = assets.getJSONObject(i).optString("browser_download_url", "");
                            if (url.endsWith(".apk")) apk = url;
                        }
                    }
                    updates.add("OK\n" + release.optString("tag_name", "") + "\n" + release.optString("html_url", "") + "\n" + apk);
                } catch (Exception e) {
                    updates.add("NONE");
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        }).start();
    }

    /** Called from Rust: the answer of the update check ("OK" and details, or "NONE"), or "". */
    public String pollUpdate() {
        String answer = updates.poll();
        return answer == null ? "" : answer;
    }

    /** Called from Rust: open a web link in the user's browser. */
    public void openLink(final String url) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    // No browser installed: nothing to open.
                }
            }
        });
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        final Uri uri = intent.getData();
        if (uri == null) return;
        intent.setData(null);
        keepAccess(uri);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String path = importDocument(uri);
                    if (path != null) opened.add(path);
                } catch (Exception e) {
                    // The document could not be read; nothing is opened.
                }
            }
        }).start();
    }

    private void keepAccess(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            // Not offered for this document: saves still work for as long as the app runs, or fail quietly.
        }
    }

    /** Copy the document into the app's private folder, remember where it came from, return the copy's path. */
    private String importDocument(Uri uri) throws Exception {
        if ("file".equals(uri.getScheme()) && uri.getPath() != null && new File(uri.getPath()).canRead()) {
            return uri.getPath();
        }
        File out = new File(newDocFolder(), displayName(uri, "document.pdf"));
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        try {
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                os.close();
            }
        } finally {
            in.close();
        }
        track(out.getAbsolutePath(), uri, out.lastModified());
        return out.getAbsolutePath();
    }

    /** Save As: PdfCraft will write this path; the sync thread copies it to the chosen document. */
    private String prepareSave(Uri uri) {
        File out = new File(newDocFolder(), displayName(uri, "document.pdf"));
        track(out.getAbsolutePath(), uri, 0);
        return out.getAbsolutePath();
    }

    private File newDocFolder() {
        File dir = new File(new File(getFilesDir(), "docs"), String.valueOf(System.currentTimeMillis()));
        dir.mkdirs();
        return dir;
    }

    private String displayName(Uri uri, String fallback) {
        String name = fallback;
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        String shown = cursor.getString(0);
                        if (shown != null && !shown.isEmpty()) name = shown;
                    }
                } finally {
                    cursor.close();
                }
            }
        } else if (uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private static String mimeFor(String name) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".odt")) return "application/vnd.oasis.opendocument.text";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".eps") || n.endsWith(".ai")) return "application/postscript";
        if (n.endsWith(".rtf")) return "application/rtf";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        return "application/octet-stream";
    }

    // ---- writing saves back to the original document -------------------------------------

    private void track(String path, Uri uri, long synced) {
        synchronized (tracked) {
            tracked.put(path, new Tracked(uri, synced));
        }
        saveTracked();
    }

    private void saveTracked() {
        Set<String> entries = new HashSet<>();
        synchronized (tracked) {
            for (Map.Entry<String, Tracked> e : tracked.entrySet()) {
                entries.add(e.getKey() + "\t" + e.getValue().uri + "\t" + e.getValue().synced);
            }
        }
        getSharedPreferences("pdfcraft", Context.MODE_PRIVATE).edit().putStringSet("tracked", entries).apply();
    }

    private void loadTracked() {
        Set<String> entries = getSharedPreferences("pdfcraft", Context.MODE_PRIVATE).getStringSet("tracked", null);
        if (entries == null) return;
        synchronized (tracked) {
            for (String entry : entries) {
                String[] parts = entry.split("\t");
                if (parts.length != 3 || !new File(parts[0]).exists()) continue;
                try {
                    tracked.put(parts[0], new Tracked(Uri.parse(parts[1]), Long.parseLong(parts[2])));
                } catch (NumberFormatException e) {
                    // Skip a damaged entry.
                }
            }
        }
    }

    private void startSyncThread() {
        Thread thread = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException e) {
                        return;
                    }
                    syncBack();
                }
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    /** Copy every private document that changed since the last copy back to its original location. */
    private void syncBack() {
        ArrayList<String> paths;
        synchronized (tracked) {
            paths = new ArrayList<>(tracked.keySet());
        }
        boolean changed = false;
        for (String path : paths) {
            Tracked t;
            synchronized (tracked) {
                t = tracked.get(path);
            }
            File file = new File(path);
            if (t == null || !file.isFile() || file.length() == 0) continue;
            long modified = file.lastModified();
            if (modified == t.synced || modified == t.failedFor || System.currentTimeMillis() - modified < 800) continue;
            try {
                copyToUri(file, t.uri);
                t.synced = modified;
                changed = true;
            } catch (Exception e) {
                t.failedFor = modified; // not writable (a read-only source): try again only after the next save
            }
        }
        if (changed) saveTracked();
    }

    private void copyToUri(File file, Uri uri) throws Exception {
        OutputStream os;
        try {
            os = getContentResolver().openOutputStream(uri, "wt");
        } catch (Exception e) {
            os = getContentResolver().openOutputStream(uri, "w");
        }
        if (os == null) throw new java.io.IOException("no output stream");
        try {
            InputStream in = new FileInputStream(file);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                in.close();
            }
        } finally {
            os.close();
        }
    }
}
