<!--
  Written for you with every android-layer zip; the workflow reads it from inside the zip.
  - The FIRST "## " section is the release notes of the next build: only what is new in it.
    It is left out of the notes if the previous release already showed it.
  - "- " lines are features: they are collected from every section into the README's feature list.
  - "* " lines are fixes and changes: shown in the release notes, not in the README.
-->
# What's new in the Android edition

## Reading mode: opens by default, bars out of the way, page fills the screen
- 📖 **Opens in Reading mode.** PDFs open in Reading mode by default (you can still change it in Preferences). Installs that already had a saved setting are switched once.
- 🫥 **Bars hide while reading.** Reading mode shows just the page. Tap the page to bring the bars back, tap again to hide them.
- ↔️ **The page fills the screen width in Reading mode.** The empty strips beside the page are gone while reading, and come back while a side panel is open. Other modes are unchanged, and you can still zoom as you like.
- 🔲 **The fit button in the side bar** returns to that full-width fit while reading. <!-- feature:fit -->
- 💯 **A zoom button next to the side bar works by touch.** While the bars are shown in Reading mode, a button shows the current zoom; tap it and pick 50% to 300% or Fit to display. (Typing a percentage in the side bar isn't possible without a keyboard.)
- 🌗 **Follows your phone's light or dark theme** by default. Pick a theme yourself in the app and that choice is kept.
* 🔧 Builds again with the newest PdfCraft: the touch support, system fonts, clipboard and file-dialog stand-ins and the Android input code were updated for upstream's new code layout.
* 🔧 The layer's own code now lives in separate files, so upstream changes break it less often.
