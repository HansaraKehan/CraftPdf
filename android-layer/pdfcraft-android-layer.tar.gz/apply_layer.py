#!/usr/bin/env python3
"""Add the Android layer to a PdfCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def sub_all(path: Path, pairs: list, label: str) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made."""
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        changes += text.count(old)
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


def patch_workspace() -> None:
    """Route rfd and arboard (no Android backends) to stand-ins. winit is already vendored by PdfCraft:
    only its Android input files are replaced (see the overlay), so its other patches stay."""
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor"]' not in text and 'exclude = ["vendor/rfd-android"' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/rfd-android", "vendor/arboard-android"]\n' + text[j + 1 :]
    lines = 'rfd = { path = "vendor/rfd-android" }\narboard = { path = "vendor/arboard-android" }\n'
    text = drop_in_patch_section(text, ["rfd", "arboard"])
    if "[patch.crates-io]" in text:
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + lines, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: no native file dialogs or clipboard crates.\n[patch.crates-io]\n" + lines
    if 'winit = { path = "vendor/winit" }' not in text:
        text = text.replace("[patch.crates-io]\n", '[patch.crates-io]\nwinit = { path = "vendor/winit" }\n', 1)
    cargo.write_text(text, encoding="utf-8")


def replace_once(path: Path, old: str, new: str, label: str, required: bool = False) -> None:
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    if old in text:
        path.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"{label}: done")
    elif new in text:
        print(f"{label}: already done")
    elif required:
        sys.exit(f"{label}: upstream changed the code this patch needs ({path.name}); the Android layer must be updated")
    else:
        print(f"{label}: skipped (upstream code changed)")


ALLOC = re.compile(
    r"(?m)^(?P<ind>[ \t]*)let \(resp_rect, resp\) = ui\.allocate_exact_size\(vec2\(content_w, content_h\), Sense::click_and_drag\(\)\);[ \t]*$"
)


def patch_canvas(canvas: Path) -> None:
    """Touch support in the page view. Finds the page widget by its shape, whatever its indentation,
    and reads `selects_text` from wherever upstream keeps it (a local, or the PageEnv struct)."""
    label = "Touch: page area and tap closes menus"
    if not canvas.exists():
        sys.exit(f"{label}: canvas.rs not found; the Android layer must be updated")
    text = canvas.read_text(encoding="utf-8")
    if "android.page_rect" in text:
        print(f"{label}: already done")
        return
    m = ALLOC.search(text)
    if not m:
        sys.exit(f"{label}: upstream changed the code this patch needs (canvas.rs); the Android layer must be updated")
    # Is `selects_text` a plain variable here, or a field of `env`?
    head = text[: m.start()]
    fn_start = head.rfind("\nfn draw_pages(")
    scope = head[fn_start:] if fn_start >= 0 else head[-6000:]
    if re.search(r"(?m)^\s*selects_text,\s*$", scope) or "let selects_text" in scope:
        sel = "selects_text"
    elif "env: &PageEnv" in scope:
        sel = "env.selects_text"
    else:
        sys.exit(f"{label}: cannot find `selects_text` near the page widget; the Android layer must be updated")
    i = m.group("ind")
    block = f"""{i}ui.ctx().data_mut(|d| {{
{i}    let key = egui::Id::new("android.page_rect");
{i}    // The page area, and whether holding a finger there selects text (the Hand tool only scrolls).
{i}    d.insert_temp(key, if hand || {sel} {{ Some((avail, {sel})) }} else {{ None::<(egui::Rect, bool)> }});
{i}}});
{i}let (resp_rect, resp) = ui.allocate_exact_size(vec2(content_w, content_h), Sense::click_and_drag());
{i}// A tap on the page closes a context menu left open (the page itself is the menu's anchor).
{i}if resp.clicked() {{
{i}    egui::Popup::close_all(ui.ctx());
{i}}}
{i}// A finger tap on the page (not on a menu above it) clears the text selection.
{i}if let Some(pos) = ui.ctx().data(|d| d.get_temp::<Option<egui::Pos2>>(egui::Id::new("android.tap_pos"))).flatten()
{i}    && resp_rect.contains(pos)
{i}    && ui.ctx().layer_id_at(pos) == Some(ui.layer_id())
{i}{{
{i}    view.selection = None;
{i}}}"""
    canvas.write_text(text[: m.start()] + block + text[m.end():], encoding="utf-8")
    print(f"{label}: done")


def first_existing(*rels: str) -> Path:
    """Upstream moves files between releases: use whichever of these paths exists."""
    for rel in rels:
        if (ROOT / rel).exists():
            return ROOT / rel
    return ROOT / rels[0]


def tweak_sources() -> None:
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftPdf"
    # eframe's `accesskit` feature only works with GameActivity; egui's own accessibility tree stays on.
    # Matched on the feature name, so other features upstream adds or reorders ("clipboard", ...) don't matter.
    eframe_line = re.compile(r'(?m)^(eframe\s*=\s*\{[^}\n]*features\s*=\s*\[)([^\]\n]*)(\])')
    ui_toml = ROOT / "crates/ui-egui/Cargo.toml"
    if ui_toml.exists():
        t = ui_toml.read_text(encoding="utf-8")
        m = eframe_line.search(t)
        if m and '"accesskit"' in m.group(2):
            feats = [f for f in re.findall(r'"[^"]+"', m.group(2)) if f != '"accesskit"']
            t = t[: m.start(2)] + ", ".join(feats) + t[m.end(2):]
            ui_toml.write_text(t, encoding="utf-8")
            print("eframe accesskit feature: removed")
        else:
            print("eframe accesskit feature: nothing to remove")
    # Touch: the Android host turns a swipe on the page into scrolling and a held finger into a selection.
    # It needs to know where the page view is (for the Hand and the text-selecting tools).
    patch_canvas(ROOT / "crates/ui-egui/src/canvas.rs")
    # The app's "releases" link (update notices, the update prompt) points at this repository.
    replace_once(
        first_existing("crates/ui-egui/src/platform/updates.rs", "crates/ui-egui/src/updates.rs"),
        'pub const RELEASES_PAGE: &str = "https://github.com/storytold/pdfcraft/releases";',
        f'pub const RELEASES_PAGE: &str = "https://github.com/{repo}/releases";',
        "Releases link",
    )
    # Android ships its fonts in /system/fonts.
    replace_once(
        ROOT / "crates/engine/src/text_fonts.rs",
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts")];',
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts"), PathBuf::from("/system/fonts")];',
        "Font folder (engine)",
    )
    replace_once(
        first_existing("crates/ui-egui/src/platform/system_fonts.rs", "crates/ui-egui/src/system_fonts.rs"),
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (interface)",
    )
    replace_once(
        ROOT / "crates/render/src/system_font.rs",
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (renderer)",
    )



def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    engine = ROOT / "crates/engine/src"
    ui = ROOT / "crates/ui-egui/src"
    sub_all(engine / "links.rs", [
        ('pub const DISCORD: &str = "https://discord.gg/artcraft";', f'pub const DISCORD: &str = "{url}";'),
        ('label: "Join the ArtCraft Discord"', 'label: "Follow the developer on GitHub"'),
    ], "Community link")
    sub_all(engine / "commands.rs", [('c("help.discord", "Join the ArtCraft Discord"', 'c("help.discord", "Follow the developer on GitHub"')], "Command")
    sub_all(ui / "widgets.rs", [('tl!("Join our Discord")', 'tl!("Follow the developer")')], "Link buttons")
    sub_all(ui / "home.rs", [('"Get help, share feedback and follow development on Discord."', '"Follow the developer of this Android build on GitHub."')], "Home page")
    sub_all(ui / "chrome.rs", [
        ('layout_no_wrap("Discord".into()', 'layout_no_wrap("Follow".into()'),
        ('"messages-square", "Discord", tab_h', '"messages-square", "Follow", tab_h'),
    ], "Title bar")

patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
tweak_sources()
rebrand()
print("Android layer applied")
