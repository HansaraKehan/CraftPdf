#!/usr/bin/env python3
"""Add the Android layer to a PdfCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


def patch_workspace() -> None:
    """Route rfd and arboard (no Android backends) to stand-ins. winit is already vendored by PdfCraft:
    only its Android input files are replaced (see the overlay), so its other patches stay."""
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor"]' not in text and 'exclude = ["vendor/rfd-android"' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/rfd-android", "vendor/arboard-android"]\n' + text[j + 1 :]
    lines = 'rfd = { path = "vendor/rfd-android" }\narboard = { path = "vendor/arboard-android" }\n'
    text = drop_in_patch_section(text, ["rfd", "arboard"])
    if "[patch.crates-io]" in text:
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + lines, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: no native file dialogs or clipboard crates.\n[patch.crates-io]\n" + lines
    if 'winit = { path = "vendor/winit" }' not in text:
        text = text.replace("[patch.crates-io]\n", '[patch.crates-io]\nwinit = { path = "vendor/winit" }\n', 1)
    cargo.write_text(text, encoding="utf-8")


def replace_once(path: Path, old: str, new: str, label: str) -> None:
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    if old in text:
        path.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"{label}: done")
    elif new in text:
        print(f"{label}: already done")
    else:
        print(f"{label}: skipped (upstream code changed)")


def tweak_sources() -> None:
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftPdf"
    # eframe's `accesskit` feature only works with GameActivity; egui's own accessibility tree stays on.
    replace_once(
        ROOT / "crates/ui-egui/Cargo.toml",
        'features = ["default_fonts", "wgpu", "accesskit", "persistence", "links"]',
        'features = ["default_fonts", "wgpu", "persistence", "links"]',
        "eframe accesskit feature",
    )
    # Touch: a drag scrolls the page; holding a finger still, then dragging, selects text.
    canvas = ROOT / "crates/ui-egui/src/canvas.rs"
    for old, new, label in [
        (
            "        } else {\n            egui::scroll_area::DragScroll::OnTouch\n        },",
            '        } else if android_flag(ui.ctx(), "android.select") {\n            egui::scroll_area::DragScroll::Never\n        } else {\n            egui::scroll_area::DragScroll::OnTouch\n        },',
            "Touch: no scrolling while selecting",
        ),
        (
            "        let (resp_rect, resp) = ui.allocate_exact_size(vec2(content_w, content_h), Sense::click_and_drag());",
            '        // A finger on the screen leaves the drag to the scroll area; a held finger selects below.\n'
            '        let page_sense = if !hand && selects_text && android_flag(ui.ctx(), "android.touch") { Sense::click() } else { Sense::click_and_drag() };\n'
            "        let (resp_rect, resp) = ui.allocate_exact_size(vec2(content_w, content_h), page_sense);",
            "Touch: page view senses taps only",
        ),
        (
            "        if !resp.dragged_by(egui::PointerButton::Primary) {\n            view.selection_drag = false;",
            '        if !resp.dragged_by(egui::PointerButton::Primary) && !android_flag(ui.ctx(), "android.select") {\n            view.selection_drag = false;',
            "Touch: selection mark",
        ),
        (
            "                    if resp.drag_started() && press_here && !over_link {",
            '                    if (resp.drag_started() || android_flag(ui.ctx(), "android.select_start")) && press_here && !over_link {',
            "Touch: hold starts selecting",
        ),
        (
            "                    if resp.dragged()\n                        && let Some(sel) = view.selection.as_mut().filter(|s| s.page == i)",
            '                    if (resp.dragged() || android_flag(ui.ctx(), "android.select"))\n                        && let Some(sel) = view.selection.as_mut().filter(|s| s.page == i)',
            "Touch: drag extends the selection",
        ),
    ]:
        replace_once(canvas, old, new, label)
    if canvas.exists() and "fn android_flag" not in canvas.read_text(encoding="utf-8"):
        with canvas.open("a", encoding="utf-8") as out:
            out.write(
                "\n/// Touch state published by the Android host (see `apps/pdfcraft-android`); false everywhere else.\n"
                "fn android_flag(ctx: &egui::Context, name: &'static str) -> bool {\n"
                "    ctx.data(|d| d.get_temp::<bool>(egui::Id::new(name))).unwrap_or(false)\n"
                "}\n"
            )
    # The app's "releases" link (update notices, the update prompt) points at this repository.
    replace_once(
        ROOT / "crates/ui-egui/src/updates.rs",
        'pub const RELEASES_PAGE: &str = "https://github.com/storytold/pdfcraft/releases";',
        f'pub const RELEASES_PAGE: &str = "https://github.com/{repo}/releases";',
        "Releases link",
    )
    # Android ships its fonts in /system/fonts.
    replace_once(
        ROOT / "crates/engine/src/text_fonts.rs",
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts")];',
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts"), PathBuf::from("/system/fonts")];',
        "Font folder (engine)",
    )
    replace_once(
        ROOT / "crates/ui-egui/src/system_fonts.rs",
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (interface)",
    )


patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
tweak_sources()
print("Android layer applied")
