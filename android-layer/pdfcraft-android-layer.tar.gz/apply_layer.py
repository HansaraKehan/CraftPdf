#!/usr/bin/env python3
"""Add the Android layer to a PdfCraft checkout. Run from the repository root."""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def sub_all(path: Path, pairs: list, label: str) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made."""
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        changes += text.count(old)
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


WINIT_GIT = re.compile(r'(?m)^winit\s*=\s*\{\s*git\s*=\s*"([^"]+)"\s*,\s*rev\s*=\s*"([0-9a-fA-F]+)"\s*\}\s*$')
WINIT_ANDROID_FILES = ["keycodes.rs", "mod.rs", "input_state.rs"]


def run(cmd: list[str], cwd: Path | None = None, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=cwd, check=True, text=True, **kw)


def fetch_winit(url: str, rev: str) -> None:
    """Newer PdfCraft pins winit to a git fork. Get that exact revision into vendor/winit-android and
    give it the Android touch/keyboard input code (as a patch when the fork's files still match, else
    by copying our files over them)."""
    dest = ROOT / "vendor/winit-android"
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    run(["git", "init", "-q"], cwd=dest)
    run(["git", "remote", "add", "origin", url], cwd=dest)
    run(["git", "fetch", "-q", "--depth", "1", "origin", rev], cwd=dest)
    run(["git", "checkout", "-q", "FETCH_HEAD"], cwd=dest)
    shutil.rmtree(dest / ".git")
    patch = HERE / "winit-android.patch"
    dry = subprocess.run(["patch", "-p1", "--dry-run", "-s", "-i", str(patch)], cwd=dest, capture_output=True, text=True)
    if dry.returncode == 0:
        run(["patch", "-p1", "-s", "-i", str(patch)], cwd=dest)
        print("winit Android input: patched")
    else:
        print("winit Android input: fork's Android files differ, copying ours over them")
    # input_state.rs is a new file; the other two are copied only when the patch did not apply.
    src = HERE / "overlay/vendor/winit/src/platform_impl/android"
    out = dest / "src/platform_impl/android"
    out.mkdir(parents=True, exist_ok=True)
    for name in WINIT_ANDROID_FILES:
        if name == "input_state.rs" or dry.returncode != 0:
            shutil.copy2(src / name, out / name)


def patch_workspace() -> None:
    """Route rfd and arboard (no Android backends) to stand-ins and winit to a copy with Android input.
    Older PdfCraft vendors winit (only its Android input files are replaced, see the overlay);
    newer PdfCraft pins a winit git fork, which is fetched and patched here."""
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor"]' not in text and 'exclude = ["vendor/rfd-android"' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/rfd-android", "vendor/arboard-android", "vendor/winit-android"]\n' + text[j + 1 :]
    git = WINIT_GIT.search(text)
    winit_path = "vendor/winit"
    if git:
        fetch_winit(git.group(1), git.group(2))
        winit_path = "vendor/winit-android"
    lines = (
        'rfd = { path = "vendor/rfd-android" }\n'
        'arboard = { path = "vendor/arboard-android" }\n'
        f'winit = {{ path = "{winit_path}" }}\n'
    )
    # Our own lines replace upstream's for these crates: a second `winit =` would be a duplicate key.
    text = drop_in_patch_section(text, ["rfd", "arboard", "winit"])
    if "[patch.crates-io]" in text:
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + lines, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: no native file dialogs or clipboard crates.\n[patch.crates-io]\n" + lines
    cargo.write_text(text, encoding="utf-8")


FAILURES: list[str] = []


def replace_once(path: Path, old: str, new: str, label: str, required: bool = False) -> None:
    """Replace one exact piece of text. `required` edits that cannot be done are collected and
    reported together at the end (file and anchor), so one run shows everything that moved."""
    if not path.exists():
        if required:
            FAILURES.append(f"{label}: {path} not found")
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    if old in text:
        path.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"{label}: done")
    elif new in text:
        print(f"{label}: already done")
    elif required:
        FAILURES.append(f"{label}: {path.relative_to(ROOT)}: anchor not found: {old.strip()[:90]!r}")
    else:
        print(f"{label}: skipped (upstream code changed)")


def hook(label: str, rels: str | tuple, anchor, new, marker: str, where: str = "after", required: bool = True) -> None:
    """Put a one-line hook next to ONE anchor line of an upstream file (a string, or a regex).

    The code the hooks call lives in overlay files, so upstream files get a line or two, never a block.
    Idempotent through `marker` (text that is in the file once the hook is in). `new` may be a function of
    the regex match when it depends on the anchor's indentation. A missing or ambiguous anchor is a
    failure that names the file and the anchor."""
    path = first_existing(*((rels,) if isinstance(rels, str) else rels))
    if not path.exists():
        if required:
            FAILURES.append(f"{label}: {rels} not found")
        print(f"{label}: skipped (file not found)")
        return
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print(f"{label}: already done")
        return
    if isinstance(anchor, str):
        count = text.count(anchor)
        found = None if count != 1 else re.search(re.escape(anchor), text)
    else:
        matches = list(anchor.finditer(text))
        count = len(matches)
        found = matches[0] if count == 1 else None
    if not found:
        if required:
            shown = anchor if isinstance(anchor, str) else anchor.pattern
            FAILURES.append(f"{label}: {path.relative_to(ROOT)}: anchor found {count} times (needs exactly 1): {shown.strip()[:90]!r}")
        print(f"{label}: skipped (anchor found {count} times)")
        return
    insert = new(found) if callable(new) else new
    if where == "after":
        text = text[: found.end()] + insert + text[found.end():]
    elif where == "before":
        text = text[: found.start()] + insert + text[found.start():]
    else:  # "replace"
        text = text[: found.start()] + insert + text[found.end():]
    path.write_text(text, encoding="utf-8")
    print(f"{label}: done")


def patch_side_gutter(src: Path) -> None:
    """The gutter beside the page (`SIDE`, 70 points, there to keep pages clear of the quick-action bar)
    is read through `side_gutter()` (overlay: canvas/android_gutter.rs), so Read mode can set it to zero.
    A plain token swap, not an anchor: a use upstream adds later just keeps the normal gutter."""
    swapped = 0
    for rel in ("canvas.rs", "canvas/navigation.rs", "canvas/zoom.rs"):
        path = src / rel
        if not path.exists():
            continue
        before = path.read_text(encoding="utf-8")
        out = []
        for line in before.splitlines(keepends=True):
            stripped = line.lstrip()
            if stripped.startswith("//") or "const SIDE" in line:
                out.append(line)
            elif stripped.startswith("use "):
                out.append(re.sub(r"\bSIDE\b", "side_gutter", line))
            else:
                out.append(re.sub(r"\bSIDE\b", "side_gutter()", line))
        after = "".join(out)
        if after != before:
            swapped += 1
            path.write_text(after, encoding="utf-8")
    print(f"Reading mode (gutter): {swapped} file(s) changed")


def patch_reading() -> None:
    """Hooks for reading mode and touch. The code itself is in overlay files
    (ui-egui/src/android_reading.rs, canvas/android_gutter.rs, canvas/android_touch.rs)."""
    src = ROOT / "crates/ui-egui/src"
    hook("Reading mode (module)", "crates/ui-egui/src/lib.rs", "mod chrome;\n", "mod android_reading;\n", "mod android_reading;")
    hook(
        "Reading mode (fields)", "crates/ui-egui/src/lib.rs", "    pub full_screen: bool,\n",
        "    /// Android: Read mode hides every bar until the page is tapped (`toggle_read_bars`).\n"
        "    pub hide_bars_in_read: bool,\n"
        "    /// The bars were brought back by a tap while reading.\n"
        "    pub(crate) read_bars_shown: bool,\n",
        "hide_bars_in_read: bool",
    )
    hook(
        "Reading mode (defaults)", "crates/ui-egui/src/app.rs", "            full_screen: false,\n",
        "            hide_bars_in_read: false,\n            read_bars_shown: false,\n", "read_bars_shown: false",
    )
    hook(
        "Reading mode (tab strip)", "crates/ui-egui/src/app.rs", "        chrome::tab_strip(self, ui);\n",
        "        let bars_hidden = self.read_bars_hidden();\n        if !bars_hidden {\n            chrome::tab_strip(self, ui);\n        }\n",
        "let bars_hidden", where="replace",
    )
    hook(
        "Reading mode (mode bar)", "crates/ui-egui/src/app.rs", "        chrome::mode_bar(self, ui);\n",
        "        if !bars_hidden {\n            chrome::mode_bar(self, ui);\n        }\n",
        "if !bars_hidden {\n            chrome::mode_bar", where="replace",
    )
    hook(
        "Reading mode (side panels)", "crates/ui-egui/src/app.rs", "        side_panels::show(self, ui);\n",
        "        if !bars_hidden {\n            side_panels::show(self, ui);\n        }\n",
        "if !bars_hidden {\n            side_panels::show", where="replace",
    )
    hook(
        "Reading mode (page width)", "crates/ui-egui/src/app.rs", "        self.sync_titles(&ctx);\n",
        "        crate::canvas::set_edge_to_edge(self.read_edge_to_edge());\n", "set_edge_to_edge", where="before",
    )
    hook(
        "Reading mode (mode change)", "crates/ui-egui/src/app/commands.rs",
        "    pub(crate) fn enter_mode(&mut self, mode: Mode) {\n", "        self.android_enter_mode(mode);\n", "android_enter_mode",
    )
    hook(
        "Reading mode (opened documents)", "crates/ui-egui/src/app/files.rs",
        re.compile(r'(?m)^        if let Some\(p\) = path \{\n(?=\s*#\[cfg\(target_os = "macos"\)\])'),
        "        self.android_after_open(activate);\n", "android_after_open", where="before",
    )
    # Page width in the canvas: the gutter value and its module, then the token swap.
    hook(
        "Reading mode (gutter module)", "crates/ui-egui/src/canvas.rs", re.compile(r"(?m)^const SIDE: f32 = [0-9.]+;[^\n]*\n"),
        "mod android_gutter;\npub(crate) use android_gutter::{set_edge_to_edge, side_gutter};\n", "mod android_gutter;",
    )
    patch_side_gutter(src)
    # The side bar: its fit button returns to the width fit while reading, and the zoom box (which cannot be
    # typed in without a keyboard) opens a list of zoom levels when tapped.
    chrome = "crates/ui-egui/src/chrome.rs"
    hook(
        "Side bar (flags)", chrome, "    let view = &mut app.views[index];\n    let mut page_display = None;\n",
        "    let touch_ui = app.hide_bars_in_read;\n"
        "    let reading_edge = app.hide_bars_in_read && app.mode == crate::Mode::Read;\n",
        "let touch_ui", where="before",
    )
    hook(
        "Side bar (fit button)", chrome, "view.fit = if view.fit == Fit::Width { Fit::Page } else { Fit::Width };",
        "view.fit = if reading_edge || view.fit != Fit::Width { Fit::Width } else { Fit::Page };", "reading_edge ||", where="replace",
    )
    hook(
        "Side bar (zoom list)", chrome, re.compile(r"(?m)^[ \t]*let r = ui\.add\(edit\)\.on_hover_text\([^\n]*\n"),
        "                if touch_ui {\n                    crate::android_reading::zoom_list(&r, view);\n                }\n", "android_reading::zoom_list",
    )


ALLOC = re.compile(
    r"(?m)^(?P<ind>[ \t]*)let \(resp_rect, resp\) = ui\.allocate_exact_size\(vec2\(content_w, content_h\), Sense::click_and_drag\(\)\);[ \t]*$"
)


def patch_canvas(canvas: Path) -> None:
    """Touch support in the page view: two one-line calls around the page widget. Finds the widget by its
    shape, whatever its indentation, and reads `selects_text` from wherever upstream keeps it."""
    label = "Touch: page area and tap closes menus"
    if not canvas.exists():
        FAILURES.append(f"{label}: canvas.rs not found")
        return
    text = canvas.read_text(encoding="utf-8")
    if "android_touch::publish_page" in text:
        print(f"{label}: already done")
        return
    matches = list(ALLOC.finditer(text))
    if len(matches) != 1:
        FAILURES.append(f"{label}: crates/ui-egui/src/canvas.rs: the page widget line (`let (resp_rect, resp) = ui.allocate_exact_size(vec2(content_w, content_h), Sense::click_and_drag());`) found {len(matches)} times (needs exactly 1)")
        return
    m = matches[0]
    # Is `selects_text` a plain variable here, or a field of `env`?
    head = text[: m.start()]
    fn_start = head.rfind("\nfn draw_pages(")
    scope = head[fn_start:] if fn_start >= 0 else head[-6000:]
    if re.search(r"(?m)^\s*selects_text,\s*$", scope) or "let selects_text" in scope:
        sel = "selects_text"
    elif "env: &PageEnv" in scope:
        sel = "env.selects_text"
    else:
        FAILURES.append(f"{label}: crates/ui-egui/src/canvas.rs: cannot find `selects_text` near the page widget")
        return
    i = m.group("ind")
    block = (
        f"{i}android_touch::publish_page(ui.ctx(), avail, hand, {sel});\n"
        f"{m.group(0)}\n"
        f"{i}android_touch::after_page(ui, &resp, resp_rect, view);"
    )
    canvas.write_text(text[: m.start()] + block + text[m.end():], encoding="utf-8")
    print(f"{label}: done")


def match_stand_in_versions() -> None:
    """A [patch] only replaces a crate when its version fits what every dependent asks for. Upstream and its
    egui fork move arboard and rfd up over time, so the stand-ins take the locked minor version (x.y.99)."""
    lock = ROOT / "Cargo.lock"
    if not lock.exists():
        return
    text = lock.read_text(encoding="utf-8")
    for crate, folder in (("arboard", "arboard-android"), ("rfd", "rfd-android")):
        found = re.search(r'(?m)^name = "' + crate + r'"\nversion = "(\d+)\.(\d+)\.\d+"', text)
        toml = ROOT / "vendor" / folder / "Cargo.toml"
        if not found or not toml.exists():
            continue
        version = f"{found.group(1)}.{found.group(2)}.99"
        t = toml.read_text(encoding="utf-8")
        t = re.sub(r'(?m)^version = "[^"]+"', f'version = "{version}"', t, count=1)
        toml.write_text(t, encoding="utf-8")
        print(f"{crate} stand-in: version {version}")


def first_existing(*rels: str) -> Path:
    """Upstream moves files between releases: use whichever of these paths exists."""
    for rel in rels:
        if (ROOT / rel).exists():
            return ROOT / rel
    return ROOT / rels[0]


def tweak_sources() -> None:
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftPdf"
    # eframe's `accesskit` feature only works with GameActivity; egui's own accessibility tree stays on.
    # Matched on the feature name, so other features upstream adds or reorders ("clipboard", ...) don't matter.
    eframe_line = re.compile(r'(?m)^(eframe\s*=\s*\{[^}\n]*features\s*=\s*\[)([^\]\n]*)(\])')
    ui_toml = ROOT / "crates/ui-egui/Cargo.toml"
    if ui_toml.exists():
        t = ui_toml.read_text(encoding="utf-8")
        m = eframe_line.search(t)
        if m and '"accesskit"' in m.group(2):
            feats = [f for f in re.findall(r'"[^"]+"', m.group(2)) if f != '"accesskit"']
            t = t[: m.start(2)] + ", ".join(feats) + t[m.end(2):]
            ui_toml.write_text(t, encoding="utf-8")
            print("eframe accesskit feature: removed")
        else:
            print("eframe accesskit feature: nothing to remove")
    # Touch: the Android host turns a swipe on the page into scrolling and a held finger into a selection.
    # It needs to know where the page view is (for the Hand and the text-selecting tools).
    hook("Touch (module)", "crates/ui-egui/src/canvas.rs", "mod area;\n", "mod android_touch;\n", "mod android_touch;")
    patch_canvas(ROOT / "crates/ui-egui/src/canvas.rs")
    # The app's "releases" link (update notices, the update prompt) points at this repository.
    replace_once(
        first_existing("crates/ui-egui/src/platform/updates.rs", "crates/ui-egui/src/updates.rs"),
        'pub const RELEASES_PAGE: &str = "https://github.com/storytold/pdfcraft/releases";',
        f'pub const RELEASES_PAGE: &str = "https://github.com/{repo}/releases";',
        "Releases link",
    )
    # Android ships its fonts in /system/fonts.
    replace_once(
        ROOT / "crates/engine/src/text_fonts.rs",
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts")];',
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts"), PathBuf::from("/system/fonts")];',
        "Font folder (engine)",
    )
    replace_once(
        first_existing("crates/ui-egui/src/platform/system_fonts.rs", "crates/ui-egui/src/system_fonts.rs"),
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (interface)",
    )
    replace_once(
        ROOT / "crates/render/src/system_font.rs",
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (renderer)",
    )



def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    engine = ROOT / "crates/engine/src"
    ui = ROOT / "crates/ui-egui/src"
    sub_all(engine / "links.rs", [
        ('pub const DISCORD: &str = "https://discord.gg/artcraft";', f'pub const DISCORD: &str = "{url}";'),
        ('label: "Join the ArtCraft Discord"', 'label: "Follow the developer on GitHub"'),
    ], "Community link")
    sub_all(engine / "commands.rs", [('c("help.discord", "Join the ArtCraft Discord"', 'c("help.discord", "Follow the developer on GitHub"')], "Command")
    sub_all(ui / "widgets.rs", [('tl!("Join our Discord")', 'tl!("Follow the developer")')], "Link buttons")
    sub_all(ui / "home.rs", [('"Get help, share feedback and follow development on Discord."', '"Follow the developer of this Android build on GitHub."')], "Home page")
    sub_all(ui / "chrome.rs", [
        ('layout_no_wrap("Discord".into()', 'layout_no_wrap("Follow".into()'),
        ('"messages-square", "Discord", tab_h', '"messages-square", "Follow", tab_h'),
    ], "Title bar")

patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
match_stand_in_versions()
tweak_sources()
patch_reading()
rebrand()
if FAILURES:
    print()
    print("::error::The Android layer could not be applied to this upstream version. Upstream moved:")
    for failure in FAILURES:
        print("  - " + failure)
    print("Send this list to the person who maintains the layer: only these hooks need updating.")
    sys.exit(1)
print("Android layer applied")
