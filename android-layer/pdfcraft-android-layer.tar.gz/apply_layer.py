#!/usr/bin/env python3
"""Add the Android layer to a PdfCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


def patch_workspace() -> None:
    """Route rfd and arboard (no Android backends) to stand-ins. winit is already vendored by PdfCraft:
    only its Android input files are replaced (see the overlay), so its other patches stay."""
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor"]' not in text and 'exclude = ["vendor/rfd-android"' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/rfd-android", "vendor/arboard-android"]\n' + text[j + 1 :]
    lines = 'rfd = { path = "vendor/rfd-android" }\narboard = { path = "vendor/arboard-android" }\n'
    text = drop_in_patch_section(text, ["rfd", "arboard"])
    if "[patch.crates-io]" in text:
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + lines, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: no native file dialogs or clipboard crates.\n[patch.crates-io]\n" + lines
    if 'winit = { path = "vendor/winit" }' not in text:
        text = text.replace("[patch.crates-io]\n", '[patch.crates-io]\nwinit = { path = "vendor/winit" }\n', 1)
    cargo.write_text(text, encoding="utf-8")


def replace_once(path: Path, old: str, new: str, label: str) -> None:
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    if old in text:
        path.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"{label}: done")
    elif new in text:
        print(f"{label}: already done")
    else:
        print(f"{label}: skipped (upstream code changed)")


def tweak_sources() -> None:
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftPdf"
    # The app's "releases" link (update notices, the update prompt) points at this repository.
    replace_once(
        ROOT / "crates/ui-egui/src/updates.rs",
        'pub const RELEASES_PAGE: &str = "https://github.com/storytold/pdfcraft/releases";',
        f'pub const RELEASES_PAGE: &str = "https://github.com/{repo}/releases";',
        "Releases link",
    )
    # Android ships its fonts in /system/fonts.
    replace_once(
        ROOT / "crates/engine/src/text_fonts.rs",
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts")];',
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts"), PathBuf::from("/system/fonts")];',
        "Font folder (engine)",
    )
    replace_once(
        ROOT / "crates/ui-egui/src/system_fonts.rs",
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (interface)",
    )


patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
tweak_sources()
print("Android layer applied")
