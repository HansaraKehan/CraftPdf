#!/usr/bin/env python3
"""Add the Android layer to a PdfCraft checkout. Run from the repository root."""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def sub_all(path: Path, pairs: list, label: str) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made."""
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        changes += text.count(old)
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


WINIT_GIT = re.compile(r'(?m)^winit\s*=\s*\{\s*git\s*=\s*"([^"]+)"\s*,\s*rev\s*=\s*"([0-9a-fA-F]+)"\s*\}\s*$')
WINIT_ANDROID_FILES = ["keycodes.rs", "mod.rs", "input_state.rs"]


def run(cmd: list[str], cwd: Path | None = None, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=cwd, check=True, text=True, **kw)


def fetch_winit(url: str, rev: str) -> None:
    """Newer PdfCraft pins winit to a git fork. Get that exact revision into vendor/winit-android and
    give it the Android touch/keyboard input code (as a patch when the fork's files still match, else
    by copying our files over them)."""
    dest = ROOT / "vendor/winit-android"
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    run(["git", "init", "-q"], cwd=dest)
    run(["git", "remote", "add", "origin", url], cwd=dest)
    run(["git", "fetch", "-q", "--depth", "1", "origin", rev], cwd=dest)
    run(["git", "checkout", "-q", "FETCH_HEAD"], cwd=dest)
    shutil.rmtree(dest / ".git")
    patch = HERE / "winit-android.patch"
    dry = subprocess.run(["patch", "-p1", "--dry-run", "-s", "-i", str(patch)], cwd=dest, capture_output=True, text=True)
    if dry.returncode == 0:
        run(["patch", "-p1", "-s", "-i", str(patch)], cwd=dest)
        print("winit Android input: patched")
    else:
        print("winit Android input: fork's Android files differ, copying ours over them")
    # input_state.rs is a new file; the other two are copied only when the patch did not apply.
    src = HERE / "overlay/vendor/winit/src/platform_impl/android"
    out = dest / "src/platform_impl/android"
    out.mkdir(parents=True, exist_ok=True)
    for name in WINIT_ANDROID_FILES:
        if name == "input_state.rs" or dry.returncode != 0:
            shutil.copy2(src / name, out / name)


def patch_workspace() -> None:
    """Route rfd and arboard (no Android backends) to stand-ins and winit to a copy with Android input.
    Older PdfCraft vendors winit (only its Android input files are replaced, see the overlay);
    newer PdfCraft pins a winit git fork, which is fetched and patched here."""
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor"]' not in text and 'exclude = ["vendor/rfd-android"' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/rfd-android", "vendor/arboard-android", "vendor/winit-android"]\n' + text[j + 1 :]
    git = WINIT_GIT.search(text)
    winit_path = "vendor/winit"
    if git:
        fetch_winit(git.group(1), git.group(2))
        winit_path = "vendor/winit-android"
    lines = (
        'rfd = { path = "vendor/rfd-android" }\n'
        'arboard = { path = "vendor/arboard-android" }\n'
        f'winit = {{ path = "{winit_path}" }}\n'
    )
    # Our own lines replace upstream's for these crates: a second `winit =` would be a duplicate key.
    text = drop_in_patch_section(text, ["rfd", "arboard", "winit"])
    if "[patch.crates-io]" in text:
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + lines, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: no native file dialogs or clipboard crates.\n[patch.crates-io]\n" + lines
    cargo.write_text(text, encoding="utf-8")


def replace_once(path: Path, old: str, new: str, label: str, required: bool = False) -> None:
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    if old in text:
        path.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"{label}: done")
    elif new in text:
        print(f"{label}: already done")
    elif required:
        sys.exit(f"{label}: upstream changed the code this patch needs ({path.name}); the Android layer must be updated")
    else:
        print(f"{label}: skipped (upstream code changed)")


def patch_side_gutter(src: Path) -> None:
    """The gutter beside the page (`SIDE`, 70 points, there to keep pages clear of the quick-action bar)
    becomes a value read through `side_gutter()`, so Read mode can set it to zero."""
    canvas = src / "canvas.rs"
    if not canvas.exists():
        print("Reading mode (gutter): skipped (canvas.rs not found)")
        return
    text = canvas.read_text(encoding="utf-8")
    if "fn side_gutter()" not in text:
        anchor = re.search(r"(?m)^const SIDE: f32 = [0-9.]+;[ \t]*$", text)
        if not anchor:
            print("Reading mode (gutter): skipped (upstream code changed)")
            return
        helper = (
            "\n/// The gutter beside the page: `SIDE`, or none while Read mode fills the screen width.\n"
            "static EDGE_TO_EDGE: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);\n\n"
            "pub(crate) fn set_edge_to_edge(on: bool) {\n"
            "    EDGE_TO_EDGE.store(on, std::sync::atomic::Ordering::Relaxed);\n"
            "}\n\n"
            "pub(crate) fn side_gutter() -> f32 {\n"
            "    if EDGE_TO_EDGE.load(std::sync::atomic::Ordering::Relaxed) { 0.0 } else { SIDE }\n"
            "}\n"
        )
        text = text[: anchor.end()] + "\n" + helper + text[anchor.end() :]
        canvas.write_text(text, encoding="utf-8")
    swapped = 0
    for rel in ("canvas.rs", "canvas/navigation.rs", "canvas/zoom.rs"):
        path = src / rel
        if not path.exists():
            continue
        out = []
        for line in path.read_text(encoding="utf-8").splitlines(keepends=True):
            stripped = line.lstrip()
            if stripped.startswith("//") or "const SIDE" in line or "else { SIDE }" in line:
                out.append(line)
            elif stripped.startswith("use "):
                out.append(re.sub(r"\bSIDE\b", "side_gutter", line))
            else:
                out.append(re.sub(r"\bSIDE\b", "side_gutter()", line))
        new = "".join(out)
        if new != path.read_text(encoding="utf-8"):
            swapped += 1
            path.write_text(new, encoding="utf-8")
    print(f"Reading mode (gutter): done ({swapped} files)")


def patch_reading() -> None:
    """Reading mode on a phone: with `hide_bars_in_read` on, Read mode shows the page and nothing else
    (tab strip, mode bar, rail and panes hidden). A tap on the page, sent by the Android host, brings the
    bars back and the next tap hides them again. Leaving or entering a mode always starts hidden."""
    src = ROOT / "crates/ui-egui/src"
    replace_once(
        src / "lib.rs",
        "    pub full_screen: bool,\n",
        "    pub full_screen: bool,\n"
        "    /// Android: Read mode hides every bar until the page is tapped ([`Self::toggle_read_bars`]).\n"
        "    pub hide_bars_in_read: bool,\n"
        "    /// The bars were brought back by a tap while reading.\n"
        "    pub(crate) read_bars_shown: bool,\n",
        "Reading mode (fields)",
    )
    replace_once(
        src / "app.rs",
        "            full_screen: false,\n",
        "            full_screen: false,\n            hide_bars_in_read: false,\n            read_bars_shown: false,\n",
        "Reading mode (defaults)",
    )
    replace_once(
        src / "app.rs",
        "        chrome::tab_strip(self, ui);\n        chrome::mode_bar(self, ui);\n",
        "        let bars_hidden = self.read_bars_hidden();\n"
        "        if !bars_hidden {\n"
        "            chrome::tab_strip(self, ui);\n"
        "            chrome::mode_bar(self, ui);\n"
        "        }\n",
        "Reading mode (top bars)",
    )
    replace_once(
        src / "app.rs",
        "        side_panels::show(self, ui);\n",
        "        if !bars_hidden {\n            side_panels::show(self, ui);\n        }\n",
        "Reading mode (side panels)",
    )
    replace_once(
        src / "app/commands.rs",
        "    pub(crate) fn enter_mode(&mut self, mode: Mode) {\n        self.mode = mode;\n",
        "    /// Whether Read mode is showing the page alone right now.\n"
        "    pub fn read_bars_hidden(&self) -> bool {\n"
        "        self.hide_bars_in_read && self.mode == Mode::Read && !self.read_bars_shown && self.active.is_some() && !self.full_screen\n"
        "    }\n\n"
        "    /// A tap on the page while reading: bring the bars back, or put them away again.\n"
        "    pub fn toggle_read_bars(&mut self) {\n"
        "        if self.hide_bars_in_read && self.mode == Mode::Read && self.active.is_some() {\n"
        "            self.read_bars_shown = !self.read_bars_shown;\n"
        "        }\n"
        "    }\n\n"
        "    pub(crate) fn enter_mode(&mut self, mode: Mode) {\n"
        "        let entering_read = self.hide_bars_in_read && mode == Mode::Read && self.mode != Mode::Read;\n"
        "        self.mode = mode;\n"
        "        // Entering or leaving Read mode starts with the bars hidden again.\n"
        "        self.read_bars_shown = false;\n"
        "        // Reading fits the page to the screen width, edge to edge (the reader can change it afterwards).\n"
        "        if entering_read && let Some(view) = self.active.and_then(|i| self.views.get_mut(i)) {\n"
        "            view.set_fit(crate::canvas::Fit::Width);\n"
        "        }\n",
        "Reading mode (enter_mode)",
    )
    # Read fills the screen width: the gutter beside the page (made for the quick-action bar, which Read
    # hides) drops to zero, and comes back while a side panel is open or outside Read mode.
    replace_once(
        src / "app.rs",
        "        self.sync_titles(&ctx);\n",
        "        crate::canvas::set_edge_to_edge(self.read_edge_to_edge());\n        self.sync_titles(&ctx);\n",
        "Reading mode (page width)",
    )
    replace_once(
        src / "app/commands.rs",
        "    /// Whether Read mode is showing the page alone right now.\n",
        "    /// Read mode with nothing beside the page: it then fills the screen width.\n"
        "    pub fn read_edge_to_edge(&self) -> bool {\n"
        "        self.hide_bars_in_read && self.mode == Mode::Read && self.right.is_none() && !self.full_screen\n"
        "    }\n\n"
        "    /// Whether Read mode is showing the page alone right now.\n",
        "Reading mode (edge to edge)",
    )
    replace_once(
        src / "app/files.rs",
        "        if let Some(p) = path {\n            #[cfg(target_os = \"macos\")]\n",
        "        // A document opened while reading fits the screen width too.\n"
        "        if activate && self.hide_bars_in_read && self.mode == Mode::Read && let Some(view) = self.views.last_mut() {\n"
        "            view.set_fit(crate::canvas::Fit::Width);\n"
        "        }\n"
        "        if let Some(p) = path {\n            #[cfg(target_os = \"macos\")]\n",
        "Reading mode (opened documents)",
    )
    patch_side_gutter(src)
    # The side bar: its fit button returns to that fit while reading, and the zoom box (which cannot be
    # typed in without a keyboard) opens a list of zoom levels when tapped.
    chrome = src / "chrome.rs"
    replace_once(
        chrome,
        "    let view = &mut app.views[index];\n    let mut page_display = None;\n",
        "    let touch_ui = app.hide_bars_in_read;\n"
        "    let reading_edge = app.hide_bars_in_read && app.mode == crate::Mode::Read;\n"
        "    let view = &mut app.views[index];\n    let mut page_display = None;\n",
        "Side bar (flags)",
    )
    replace_once(
        chrome,
        "                    view.fit = if view.fit == Fit::Width { Fit::Page } else { Fit::Width };\n",
        "                    view.fit = if reading_edge || view.fit != Fit::Width { Fit::Width } else { Fit::Page };\n",
        "Side bar (fit button)",
    )
    replace_once(
        chrome,
        "                let r = ui.add(edit).on_hover_text(tl!(\"Zoom \u2014 type a percentage and press Enter\"));\n",
        "                let r = ui.add(edit).on_hover_text(tl!(\"Zoom \u2014 type a percentage and press Enter\"));\n"
        "                if touch_ui {\n"
        "                    // No keyboard to type a percentage with: tap the box to pick one.\n"
        "                    let picked = egui::Popup::menu(&r)\n"
        "                        .show(|ui| {\n"
        "                            let mut picked = None;\n"
        "                            for percent in [50, 75, 100, 125, 150, 200, 300] {\n"
        "                                if ui.button(format!(\"{percent}%\")).clicked() {\n"
        "                                    picked = Some(percent as f32 / 100.0);\n"
        "                                    ui.close();\n"
        "                                }\n"
        "                            }\n"
        "                            picked\n"
        "                        })\n"
        "                        .and_then(|r| r.inner);\n"
        "                    if let Some(zoom) = picked {\n"
        "                        view.set_zoom(zoom);\n"
        "                    }\n"
        "                }\n",
        "Side bar (zoom list)",
    )


ALLOC = re.compile(
    r"(?m)^(?P<ind>[ \t]*)let \(resp_rect, resp\) = ui\.allocate_exact_size\(vec2\(content_w, content_h\), Sense::click_and_drag\(\)\);[ \t]*$"
)


def patch_canvas(canvas: Path) -> None:
    """Touch support in the page view. Finds the page widget by its shape, whatever its indentation,
    and reads `selects_text` from wherever upstream keeps it (a local, or the PageEnv struct)."""
    label = "Touch: page area and tap closes menus"
    if not canvas.exists():
        sys.exit(f"{label}: canvas.rs not found; the Android layer must be updated")
    text = canvas.read_text(encoding="utf-8")
    if "android.page_rect" in text:
        print(f"{label}: already done")
        return
    m = ALLOC.search(text)
    if not m:
        sys.exit(f"{label}: upstream changed the code this patch needs (canvas.rs); the Android layer must be updated")
    # Is `selects_text` a plain variable here, or a field of `env`?
    head = text[: m.start()]
    fn_start = head.rfind("\nfn draw_pages(")
    scope = head[fn_start:] if fn_start >= 0 else head[-6000:]
    if re.search(r"(?m)^\s*selects_text,\s*$", scope) or "let selects_text" in scope:
        sel = "selects_text"
    elif "env: &PageEnv" in scope:
        sel = "env.selects_text"
    else:
        sys.exit(f"{label}: cannot find `selects_text` near the page widget; the Android layer must be updated")
    i = m.group("ind")
    block = f"""{i}ui.ctx().data_mut(|d| {{
{i}    let key = egui::Id::new("android.page_rect");
{i}    // The page area, and whether holding a finger there selects text (the Hand tool only scrolls).
{i}    d.insert_temp(key, if hand || {sel} {{ Some((avail, {sel})) }} else {{ None::<(egui::Rect, bool)> }});
{i}}});
{i}let (resp_rect, resp) = ui.allocate_exact_size(vec2(content_w, content_h), Sense::click_and_drag());
{i}// A tap on the page closes a context menu left open (the page itself is the menu's anchor).
{i}if resp.clicked() {{
{i}    egui::Popup::close_all(ui.ctx());
{i}}}
{i}// A finger tap on the page (not on a menu above it) clears the text selection.
{i}if let Some(pos) = ui.ctx().data(|d| d.get_temp::<Option<egui::Pos2>>(egui::Id::new("android.tap_pos"))).flatten()
{i}    && resp_rect.contains(pos)
{i}    && ui.ctx().layer_id_at(pos) == Some(ui.layer_id())
{i}{{
{i}    view.selection = None;
{i}}}"""
    canvas.write_text(text[: m.start()] + block + text[m.end():], encoding="utf-8")
    print(f"{label}: done")


def match_stand_in_versions() -> None:
    """A [patch] only replaces a crate when its version fits what every dependent asks for. Upstream and its
    egui fork move arboard and rfd up over time, so the stand-ins take the locked minor version (x.y.99)."""
    lock = ROOT / "Cargo.lock"
    if not lock.exists():
        return
    text = lock.read_text(encoding="utf-8")
    for crate, folder in (("arboard", "arboard-android"), ("rfd", "rfd-android")):
        found = re.search(r'(?m)^name = "' + crate + r'"\nversion = "(\d+)\.(\d+)\.\d+"', text)
        toml = ROOT / "vendor" / folder / "Cargo.toml"
        if not found or not toml.exists():
            continue
        version = f"{found.group(1)}.{found.group(2)}.99"
        t = toml.read_text(encoding="utf-8")
        t = re.sub(r'(?m)^version = "[^"]+"', f'version = "{version}"', t, count=1)
        toml.write_text(t, encoding="utf-8")
        print(f"{crate} stand-in: version {version}")


def first_existing(*rels: str) -> Path:
    """Upstream moves files between releases: use whichever of these paths exists."""
    for rel in rels:
        if (ROOT / rel).exists():
            return ROOT / rel
    return ROOT / rels[0]


def tweak_sources() -> None:
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftPdf"
    # eframe's `accesskit` feature only works with GameActivity; egui's own accessibility tree stays on.
    # Matched on the feature name, so other features upstream adds or reorders ("clipboard", ...) don't matter.
    eframe_line = re.compile(r'(?m)^(eframe\s*=\s*\{[^}\n]*features\s*=\s*\[)([^\]\n]*)(\])')
    ui_toml = ROOT / "crates/ui-egui/Cargo.toml"
    if ui_toml.exists():
        t = ui_toml.read_text(encoding="utf-8")
        m = eframe_line.search(t)
        if m and '"accesskit"' in m.group(2):
            feats = [f for f in re.findall(r'"[^"]+"', m.group(2)) if f != '"accesskit"']
            t = t[: m.start(2)] + ", ".join(feats) + t[m.end(2):]
            ui_toml.write_text(t, encoding="utf-8")
            print("eframe accesskit feature: removed")
        else:
            print("eframe accesskit feature: nothing to remove")
    # Touch: the Android host turns a swipe on the page into scrolling and a held finger into a selection.
    # It needs to know where the page view is (for the Hand and the text-selecting tools).
    patch_canvas(ROOT / "crates/ui-egui/src/canvas.rs")
    # The app's "releases" link (update notices, the update prompt) points at this repository.
    replace_once(
        first_existing("crates/ui-egui/src/platform/updates.rs", "crates/ui-egui/src/updates.rs"),
        'pub const RELEASES_PAGE: &str = "https://github.com/storytold/pdfcraft/releases";',
        f'pub const RELEASES_PAGE: &str = "https://github.com/{repo}/releases";',
        "Releases link",
    )
    # Android ships its fonts in /system/fonts.
    replace_once(
        ROOT / "crates/engine/src/text_fonts.rs",
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts")];',
        'let mut dirs = vec![PathBuf::from("/usr/share/fonts"), PathBuf::from("/usr/local/share/fonts"), PathBuf::from("/system/fonts")];',
        "Font folder (engine)",
    )
    replace_once(
        first_existing("crates/ui-egui/src/platform/system_fonts.rs", "crates/ui-egui/src/system_fonts.rs"),
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (interface)",
    )
    replace_once(
        ROOT / "crates/render/src/system_font.rs",
        '["/usr/share/fonts", "/usr/local/share/fonts"].iter()',
        '["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts"].iter()',
        "Font folder (renderer)",
    )



def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    engine = ROOT / "crates/engine/src"
    ui = ROOT / "crates/ui-egui/src"
    sub_all(engine / "links.rs", [
        ('pub const DISCORD: &str = "https://discord.gg/artcraft";', f'pub const DISCORD: &str = "{url}";'),
        ('label: "Join the ArtCraft Discord"', 'label: "Follow the developer on GitHub"'),
    ], "Community link")
    sub_all(engine / "commands.rs", [('c("help.discord", "Join the ArtCraft Discord"', 'c("help.discord", "Follow the developer on GitHub"')], "Command")
    sub_all(ui / "widgets.rs", [('tl!("Join our Discord")', 'tl!("Follow the developer")')], "Link buttons")
    sub_all(ui / "home.rs", [('"Get help, share feedback and follow development on Discord."', '"Follow the developer of this Android build on GitHub."')], "Home page")
    sub_all(ui / "chrome.rs", [
        ('layout_no_wrap("Discord".into()', 'layout_no_wrap("Follow".into()'),
        ('"messages-square", "Discord", tab_h', '"messages-square", "Follow", tab_h'),
    ], "Title bar")

patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
match_stand_in_versions()
tweak_sources()
patch_reading()
rebrand()
print("Android layer applied")
